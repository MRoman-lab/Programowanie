# Programowanie Zaawansowane - Projekt Klient-Serwer

## Skład zespołu
* Jakub Pawłowski - projekt architektury, implementacja serwera, klienta, mechanizmu wielowątkowości oraz zautomatyzowanych testów.

## Instrukcja techniczna
### Wymagania
* Java 19 (lub nowsza)
* Środowisko IDE (np. IntelliJ IDEA)

### Uruchomienie aplikacji
1. Skompiluj projekt w swoim środowisku IDE.
2. Uruchom klasę `Serwer` (plik `Serwer.java`). W konsoli pojawi się informacja o nasłuchiwaniu na porcie 8080 oraz logi inicjalizacji mapy.
3. Uruchom klasę `Klient` (plik `Klient.java`). Klient nawiąże połączenie, pobierze dane z użyciem Stream API oraz celowo wywoła błąd rzutowania (ClassCastException) w celu jego obsłużenia.
4. Aby przetestować limit połączeń, uruchom cztery instancje klasy `Klient` równocześnie. Czwarty klient otrzyma natychmiastowy status `REFUSED`.

### Uruchomienie testów
1. Upewnij się, że biblioteka JUnit 5 (wersja 5.8.1 lub nowsza) jest dodana do classpath projektu.
2. Przed uruchomieniem testów zamknij wszystkie działające ręcznie instancje serwera, aby zwolnić port 8080.
3. Uruchom klasę `AplikacjaTest`. Przeprowadzi ona automatycznie testy jednostkowe, integracyjne oraz E2E (weryfikacja limitu klientów).

## Deklaracja użycia sztucznej inteligencji
W trakcie realizacji projektu korzystano z pomocy asystenta AI (Google Gemini).
* **Zastosowanie:** Narzędzie zostało wykorzystane jako wsparcie przy generowaniu powtarzalnych elementów kodu (np. metody `equals` i `toString` w klasach modeli), rozwiązywaniu problemów z obsługą wyjątków przy strumieniach danych sieciowych oraz podczas konfiguracji biblioteki testowej JUnit 5 w środowisku IntelliJ IDEA.
* **Przykładowe prompty:** * "Wygeneruj standardowe metody equals i toString dla klasy posiadającej dwa pola typu String"
    * "Jak naprawić błąd StreamCorruptedException przy przesyłaniu obiektów w Javie"
    * "Jak szybko podpiąć bibliotekę JUnit 5 do projektu w IntelliJ IDEA"
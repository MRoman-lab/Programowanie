import java.io.Serializable;
import java.util.Objects;

public class Zadanie implements Serializable {
    private int idZadania;
    private String opis;

    public Zadanie(int idZadania, String opis) {
        this.idZadania = idZadania;
        this.opis = opis;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Zadanie zadanie = (Zadanie) o;
        return idZadania == zadanie.idZadania && Objects.equals(opis, zadanie.opis);
    }

    @Override
    public String toString() {
        return "Zadanie{idZadania=" + idZadania + ", opis='" + opis + "'}";
    }
}
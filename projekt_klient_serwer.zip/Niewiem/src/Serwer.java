import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class Serwer {
    private static final int MAX_CLIENTS = 3;
    private static int aktualniKlienci = 0;
    private static final Map<String, Serializable> bazaDanych = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        inicjalizujMape();
        try (ServerSocket serverSocket = new ServerSocket(8080)) {
            System.out.println("Serwer wystartował. Nasłuchuje na porcie 8080...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                synchronized (Serwer.class) {
                    if (aktualniKlienci >= MAX_CLIENTS) {
                        // Odrzucenie nadmiarowego klienta przez strumień obiektowy
                        ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                        out.writeObject("REFUSED");
                        out.flush();
                        System.out.println("Odrzucono połączenie - przekroczony limit klientów.");
                        clientSocket.close();
                        continue;
                    }
                    aktualniKlienci++;
                }
                new Thread(new ObslugaKlienta(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void inicjalizujMape() {
        for (int i = 1; i <= 4; i++) {
            bazaDanych.put("Uzytkownik_" + i, new Uzytkownik("admin_" + i, "Rola_" + i));
            bazaDanych.put("Urzadzenie_" + i, new Urzadzenie("192.168.0." + i, true));
            bazaDanych.put("Zadanie_" + i, new Zadanie(i, "Opis zadania nr " + i));
        }
        System.out.println("Zainicjalizowano mapę danymi (po 4 instancje klas).");
    }

    public static synchronized void zmniejszLiczbeKlientow() {
        aktualniKlienci--;
    }

    public static Map<String, Serializable> getBaza() {
        return bazaDanych;
    }
}

class ObslugaKlienta implements Runnable {
    private final Socket socket;

    public ObslugaKlienta(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream())
        ) {
            out.flush();
            Thread.sleep(new Random().nextInt(1500) + 500);

            String clientId = (String) in.readObject();
            System.out.println("Zarejestrowano i obsługuję klienta ID: " + clientId);

            out.writeObject("OK");
            out.flush();

            String zadanaKlasa = (String) in.readObject();
            List<Serializable> odpowiedz = new ArrayList<>();
            boolean znaleziono = false;

            for (Map.Entry<String, Serializable> entry : Serwer.getBaza().entrySet()) {
                if (entry.getKey().startsWith(zadanaKlasa + "_")) {
                    odpowiedz.add(entry.getValue());
                    znaleziono = true;
                }
            }

            if (!znaleziono) {
                System.out.println("Nie znaleziono klasy " + zadanaKlasa + ". Odsyłam inny obiekt celowo.");
                odpowiedz.add(new Urzadzenie("BŁĘDNY IP", false));
            }

            out.writeObject(odpowiedz);
            out.flush();
            System.out.println("Przesłano kolekcję (" + odpowiedz.size() + " elementów) do klienta ID: " + clientId);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            Serwer.zmniejszLiczbeKlientow();
            try { socket.close(); } catch (IOException e) {}
        }
    }
}
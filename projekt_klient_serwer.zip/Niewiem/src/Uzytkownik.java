import java.io.Serializable;
import java.util.Objects;

public class Uzytkownik implements Serializable {
    private String login;
    private String rola;

    public Uzytkownik(String login, String rola) {
        this.login = login;
        this.rola = rola;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Uzytkownik that = (Uzytkownik) o;
        return Objects.equals(login, that.login) && Objects.equals(rola, that.rola);
    }

    @Override
    public String toString() {
        return "Uzytkownik{" + "login='" + login + '\'' + ", rola='" + rola + '\'' + '}';
    }
}
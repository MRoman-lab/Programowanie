import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import java.io.*;
import java.net.Socket;

import static org.junit.jupiter.api.Assertions.*;

public class AplikacjaTest {

    @Test
    public void testMetodyEqualsWModelu() {
        Uzytkownik u1 = new Uzytkownik("admin_1", "Rola_1");
        Uzytkownik u2 = new Uzytkownik("admin_1", "Rola_1");
        Uzytkownik u3 = new Uzytkownik("inny", "Rola_1");

        assertEquals(u1, u2, "Obiekty o tych samych danych powinny być równe");
        assertNotEquals(u1, u3, "Obiekty o różnych danych nie powinny być równe");
    }

    @Test
    public void testInicjalizacjiMapySerwera() throws Exception {
        java.lang.reflect.Method method = Serwer.class.getDeclaredMethod("inicjalizujMape");
        method.setAccessible(true);
        method.invoke(null);

        assertFalse(Serwer.getBaza().isEmpty(), "Mapa bazy danych nie powinna być pusta");
        assertTrue(Serwer.getBaza().containsKey("Uzytkownik_1"), "Mapa powinna zawierać Uzytkownik_1");
    }

    @Test
    public void testSerializacjiIDeserializacji() throws IOException, ClassNotFoundException {
        Urzadzenie urzadzenie = new Urzadzenie("192.168.1.100", true);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);

        oos.writeObject(urzadzenie);
        oos.close();

        ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
        ObjectInputStream ois = new ObjectInputStream(bais);
        Urzadzenie zdeserializowane = (Urzadzenie) ois.readObject();

        assertEquals(urzadzenie, zdeserializowane, "Zdeserializowany obiekt musi być taki sam jak wejściowy");
    }

    @BeforeAll
    public static void uruchomSerwerWtle() {
        Thread serverThread = new Thread(() -> Serwer.main(new String[]{}));
        serverThread.setDaemon(true);
        serverThread.start();

        try { Thread.sleep(1000); } catch (InterruptedException e) {}
    }

    @Test
    public void testObslugiOrazOdrzuceniaNadmiarowegoKlienta() {
        try {
            Socket k1 = new Socket("localhost", 8080);
            Socket k2 = new Socket("localhost", 8080);
            Socket k3 = new Socket("localhost", 8080);

            Socket k4 = new Socket("localhost", 8080);
            // Zmiana na odbiór obiektu, żeby wyeliminować StreamCorruptedException w teście
            ObjectInputStream in4 = new ObjectInputStream(k4.getInputStream());
            String odpowiedzSerwera = (String) in4.readObject();

            assertEquals("REFUSED", odpowiedzSerwera, "Nadmiarowy klient musi otrzymać komunikat REFUSED");

            k1.close(); k2.close(); k3.close(); k4.close();

        } catch (Exception e) {
            fail("Wystąpił błąd podczas połączenia: " + e.getMessage());
        }
    }
}
import java.io.*;
import java.net.*;
import java.util.List;

public class Klient {
    public static void main(String[] args) {
        int myId = (int) (Math.random() * 10000);
        System.out.println("Uruchamiam klienta z ID: " + myId);

        // Pierwsze zapytanie - poprawne rzutowanie
        wykonajZapytanie(myId, "Uzytkownik");

        // Drugie zapytanie - błąd rzutowania
        wykonajZapytanie(myId, "NieistniejacaKlasa");
    }

    private static void wykonajZapytanie(int myId, String zadanaKlasa) {
        System.out.println("\n--- Rozpoczynam zapytanie o klasę: " + zadanaKlasa + " ---");
        try (Socket socket = new Socket("localhost", 8080);
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

            // Wysyłka ID
            out.writeObject(String.valueOf(myId));
            out.flush();

            // Odbiór statusu jako obiekt String
            String status = (String) in.readObject();

            if ("REFUSED".equals(status)) {
                System.out.println("Klient ID " + myId + ": REFUSED. Przekroczony limit serwera. Kończę.");
                return;
            }

            System.out.println("Klient ID " + myId + ": Połączenie OK.");

            // Żądanie kolekcji
            out.writeObject(zadanaKlasa);
            out.flush();

            // Odbiór kolekcji
            List<?> odebranaKolekcja = (List<?>) in.readObject();

            odebranaKolekcja.stream().forEach(obj -> {
                try {
                    Uzytkownik uzytkownik = (Uzytkownik) obj;
                    System.out.println("[ID: " + myId + "] Odczytano poprawnie: " + uzytkownik);
                } catch (ClassCastException e) {
                    System.err.println("[ID: " + myId + "] BŁĄD RZUTOWANIA! Otrzymano obiekt klasy: " + obj.getClass().getSimpleName() + " a oczekiwano Uzytkownika.");
                }
            });

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
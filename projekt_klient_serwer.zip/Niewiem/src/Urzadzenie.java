import java.io.Serializable;
import java.util.Objects;

public class Urzadzenie implements Serializable {
    private String adresIP;
    private boolean czyAktywne;

    public Urzadzenie(String adresIP, boolean czyAktywne) {
        this.adresIP = adresIP;
        this.czyAktywne = czyAktywne;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Urzadzenie that = (Urzadzenie) o;
        return czyAktywne == that.czyAktywne && Objects.equals(adresIP, that.adresIP);
    }

    @Override
    public String toString() {
        return "Urzadzenie{adresIP='" + adresIP + "', czyAktywne=" + czyAktywne + "}";
    }
}